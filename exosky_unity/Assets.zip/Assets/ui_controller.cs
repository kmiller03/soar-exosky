using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using textmesh pro
using TMPro;

public class ui_controller : MonoBehaviour
{
    //text object for exoplanet name
    public TextMeshProUGUI exoplanetName;
    public void SelectExoplanet(string planetName)
    {
        //Change the text of the exoplanet name
        exoplanetName.text = planetName;
    }
}
